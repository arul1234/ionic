import { NgModule } from '@angular/core';
import { YouTubeDirective } from './you-tube/you-tube';
@NgModule({
	declarations: [YouTubeDirective],
	imports: [],
	exports: [YouTubeDirective]
})
export class DirectivesModule {}
