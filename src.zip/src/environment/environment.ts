export const environment = {
    apiKey: "AIzaSyBs57tQ6l-2W4Km35u6_2a34j0tvwRg7Z4",
    authDomain: "lotto-95f51.firebaseapp.com",
    databaseURL: "https://lotto-95f51.firebaseio.com",
    projectId: "lotto-95f51",
    storageBucket: "lotto-95f51.appspot.com",
    messagingSenderId: "517513456739"
};
